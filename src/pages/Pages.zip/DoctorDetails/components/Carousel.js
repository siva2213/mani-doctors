import React, { useState, useEffect } from "react";

import { useSwipeable } from "react-swipeable";
import { motion } from "framer-motion";
import "./styles.css";
import { ReactComponent as Quotes } from "../assets/Quotes.svg";
import { ReactComponent as StarBlack } from "../assets/Starblack.svg";
import { ReactComponent as Teeth } from "../assets/teeth.svg";
import { ReactComponent as Braces } from "../assets/braces.svg";
import { ReactComponent as Root } from "../assets/rootsvg.svg";
import { ReactComponent as Plucker } from "../assets/pluckersvg.svg";

import ReviewPic from "../assets/Pexels Photo by Lokman Sevim.png";
export const CarouselOne = (props) => {
  const [position, positionSet] = useState(0);
  const handlersBox = useSwipeable({
    onSwiped: ({ dir, event }) => {
      // NOTE: this stops the propagation of the event
      // from reaching the document swipe listeners
      event.stopPropagation();
      if (dir === "Left") {
        if (position < props.reviews.length - 1) {
          console.log(position);
          positionSet((prevState) => prevState + 1);
          props.setPillPos(position + 1);
          console.log(position);
        }
      }
      if (dir === "Right") {
        if (position > 0) {
          positionSet(position - 1);
          props.setPillPos(position - 1);
        }
      }
    },
    // NOTE: another approach via onSwiping
    // onSwiping: ({ event }) => event.stopPropagation(),
    preventDefaultTouchmoveEvent: true,
  });

  // attach swipeable to document

  return (
    <div className=' window  py-2 h-[350px] px-5 w-full  rounded-[30px]'>
      <div {...handlersBox}>
        <div className='row'>
          {props.reviews.map((data, index) => (
            <motion.div
              key={index}
              animate={{
                left: `${(index - position) * 120}vw`,
              }}
              transition={{
                type: "spring",
                stiffness: 260,
                damping: 20,
              }}
              className='container'
            >
              <div
                // style={{
                //   boxShadow:
                //     " -10px -10px 20px 0px #FAF6FB,10px 10px 20px 0px #FAF6FB  ",
                // }}
                className=' drop-shadow-xl shadow-md container  px-5 py-4 rounded-[30px] min-w-full  h-[275px] bg-gradient-to-r from-[#F3EDF4] via-[#F3EDF4] to-[#FFDCFE80]'
              >
                <div className='flex  justify-between items-center'>
                  <div className=' flex items-center'>
                    <img
                      src={ReviewPic}
                      className=' rounded-full shadow-sm w-[90px] h-[90px]'
                      alt=''
                    />
                    <div className='ml-4'>
                      <h5 className='font-bold text-[16px]'>Ruth Frazier</h5>
                      <div className='mt-2 shadow-sm h-[22px] w-[50px]   rounded-[20px] flex justify-evenly items-center bg-[#F5D4E7]'>
                        <StarBlack />
                        <p className='text-black font-black text-[10px] '>
                          4.5
                        </p>
                      </div>
                    </div>
                  </div>
                  <Quotes />
                </div>
                <div
                  className='p-5 rounded-[20px] bg-[#F3EDF4] mt-3'
                  style={{
                    boxShadow:
                      " -5px -5px 10px 0px #FAF6FB inset,5px 5px 10px 0px #DFD3E1 inset  ",
                  }}
                >
                  <p className=' leading-[1.1] font-normal text-[13px]'>
                    {data.comment}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};
