import React, { useState } from "react";
import downArrow from "../assets/downArrow.svg";
export const Input = (props) => {
  const [inFocus, setInFocus] = useState(false);
  return (
    <div className={" " + props.className}>
      {inFocus && (
        <div className=' relative p-4 mb-4'>
          <div className='bg-clip-text text-transparent bg-gradient-to-br from-gradientPurple to-gradientRed font-extrabold  text-[10px]'>
            You can either mention Dr. or just write your name. Name will appear
            in the app exactly how you write here. You can write like Rajiv Lal,
            Dr. Rajiv Lal or you can just write Rajiv. Dont worry about the
            mistakes you make , it can be edited later wheN you see in the app.
          </div>
          <div className=' absolute z-[0] opacity-40 top-0 left-0 right-0 bottom-0 rounded-[25px] p-5 text-[10px] bg-gradient-to-br from-gradientPurple to-gradientRed '></div>
        </div>
      )}
      <div className=' relative'>
        {inFocus && (
          <label
            for={props.title}
            className=' bg-darkBg top-[-8px] left-9 pl-3 pr-2 text-[13px] font-semibold text-white absolute'
          >
            {props.title}
          </label>
        )}
        <div
          className={`p-[2px] rounded-full ${
            !inFocus
              ? "bg-grayBorder"
              : " bg-gradient-to-r from-gradientPurple to-gradientRed"
          }`}
        >
          <input
            id={props.title}
            className='text-white font-extrabold bg-darkBg w-full h-[56px] p-6 rounded-full  border-0 text-[16px] focus:outline-none '
            placeholder={inFocus ? "" : props.title}
            onFocus={() => {
              setInFocus(true);
            }}
            onBlur={() => {
              setInFocus(false);
            }}
          />
        </div>
      </div>
    </div>
  );
};
export const InputNumb = (props) => {
  const [inFocus, setInFocus] = useState(false);
  return (
    <div className={" " + props.className}>
      {inFocus && (
        <div className=' relative p-4 mb-4'>
          <div className='bg-clip-text text-transparent bg-gradient-to-br from-gradientPurple to-gradientRed font-extrabold  text-[10px]'>
            You can either mention Dr. or just write your name. Name will appear
            in the app exactly how you write here. You can write like Rajiv Lal,
            Dr. Rajiv Lal or you can just write Rajiv. Dont worry about the
            mistakes you make , it can be edited later wheN you see in the app.
          </div>
          <div className=' absolute z-[0] opacity-40 top-0 left-0 right-0 bottom-0 rounded-[25px] p-5 text-[10px] bg-gradient-to-br from-gradientPurple to-gradientRed '></div>
        </div>
      )}

      <div className='flex w-full justify-between'>
        <div
          className=' w-[80px] h-[60px] bg-darkBg rounded-full flex justify-center items-center'
          style={{
            filter: "drop-shadow(2px 5px 10px #111)",
          }}
        >
          <p className='text-white text-[16px] font-black flex'>
            +91
            <img src={downArrow} className='ml-1' alt='' />
          </p>
        </div>
        <div className=' relative'>
          {inFocus && (
            <label
              for={props.title}
              className=' bg-darkBg top-[-8px] left-9 pl-3 pr-2 text-[13px] font-semibold text-white absolute'
            >
              {props.title}
            </label>
          )}
          <div
            className={`p-[2px] rounded-full ${
              !inFocus
                ? "bg-grayBorder"
                : " bg-gradient-to-r from-gradientPurple to-gradientRed"
            }`}
          >
            <input
              id={props.title}
              className='text-white font-extrabold bg-darkBg w-full h-[56px] p-6 rounded-full  border-0 text-[16px] focus:outline-none '
              placeholder={inFocus ? "" : props.title}
              onFocus={() => {
                setInFocus(true);
              }}
              onBlur={() => {
                setInFocus(false);
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
